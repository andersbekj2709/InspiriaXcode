//
//  ViewController.swift
//  InspiriaApp
//
//  Created by Anders Kjølberg on 10.04.2017.
//  Copyright © 2017 Anders Kjølberg. All rights reserved.
//

import UIKit
import WebKit
class ViewController: UIViewController {
    
    //@IBOutlet weak var myWebView:UIWebView!
    
    override func viewDidLoad() {
        //super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //let url = URL(string: "https://kahoot.it")
        //myWebView.loadRequest(URLRequest(url: url!))
        
    }

    /*
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 */

}

